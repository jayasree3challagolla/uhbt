#ifndef PURCHASE_H
#define PURCHASE_H

#include <string>

class Purchase {
private:
    std::string item;
    int quantity;
    double cost;

public:
    Purchase(const std::string& item, int quantity, double cost);
    Purchase();
    std::string getItem() const;
    void setItem(const std::string& item);
    int getQuantity() const;
    void setQuantity(int quantity);
    double getCost() const;
    void setCost(double cost);
    double getTotal() const;
    void display() const;
};

#endif
