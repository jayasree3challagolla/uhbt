#include <iostream>
#include "Purchase.h"
#include <cmath>
#include <sstream>
#include <iomanip>

Purchase::Purchase(const std::string& item, int quantity, double cost)
    : item(item), quantity(quantity), cost(cost) {}

Purchase::Purchase() {}

std::string Purchase::getItem() const {
    return item;
}
void Purchase::setItem(const std::string& item) {
    this->item = item;
}

double Purchase::getTotal() const {
    return quantity * cost;
}



double Purchase::getCost() const {
    return cost;
}

void Purchase::setCost(double cost) {
    this->cost = cost;
}

int Purchase::getQuantity() const {
    return quantity;
}

void Purchase::setQuantity(int quantity) {
    this->quantity = quantity;
}





void Purchase::display() const {
    std::stringstream scost;
    scost << std::fixed << std::setprecision(2) << cost;

    std::stringstream stotal;
    stotal << std::fixed << std::setprecision(2) << getTotal();

    std::cout << item << "\t\t\t" << scost.str() << "\t\t" << quantity << "\t\t" << stotal.str() << std::endl;
}
