#ifndef COMPANY_H
#define COMPANY_H
#include "Customer.h"
#include "Employee.h"
#include <string>
#include <vector>


class Company {
private:
    std::string name;
    std::vector<Employee*> employees;
    std::vector<Customer*> customers;

public:
    Company(const std::string& name);
    ~Company();

    std::string getName() const;
    void setName(const std::string& name);

    const std::vector<Employee*>& getEmployees() const;
    void setEmployees(const std::vector<Employee*>& employees);
    void addEmployee(Employee* employee);

    const std::vector<Customer*>& getCustomers() const;
    void setCustomers(const std::vector<Customer*>& customers);
    void addCustomer(Customer* customer);

    std::string toString() const;
};

#endif
