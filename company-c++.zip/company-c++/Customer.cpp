#include "Customer.h"

Customer::Customer() {}


Customer::Customer(const std::string& name, const std::string& email, const std::string& phone, const std::vector<Purchase>& history)
    : Person(name, email, phone), history(history) {}

std::vector<Purchase> Customer::getHistory() const {
    return history;
}


void Customer::addPurchase(const Purchase& purchase) {
    history.push_back(purchase);
}


