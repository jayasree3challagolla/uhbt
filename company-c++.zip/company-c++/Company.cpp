#include "Company.h"

Company::Company(const std::string& name) : name(name) {}

Company::~Company() {

    for (Employee* employee : employees) {
        delete employee;
    }

    for (Customer* customer : customers) {
        delete customer;
    }
}

void Company::setCustomers(const std::vector<Customer*>& customers) {
    this->customers = customers;
}

void Company::addCustomer(Customer* customer) {
    customers.push_back(customer);
}


const std::vector<Customer*>& Company::getCustomers() const {
    return customers;
}

void Company::setName(const std::string& name) {
    this->name = name;
}

const std::vector<Employee*>& Company::getEmployees() const {
    return employees;
}



std::string Company::getName() const {
    return name;
}


void Company::setEmployees(const std::vector<Employee*>& employees) {
    this->employees = employees;
}

void Company::addEmployee(Employee* employee) {
    employees.push_back(employee);
}




std::string Company::toString() const {
    return "Name: " + name + ", employees: " + std::to_string(employees.size()) + ", customers: " + std::to_string(customers.size());
}
