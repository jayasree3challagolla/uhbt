#ifndef CUSTOMER_H
#define CUSTOMER_H
#include "Person.h"
#include "Purchase.h"
#include <vector>


class Customer : public Person {
private:
    std::vector<Purchase> history;
public:
    Customer();
    Customer(const std::string& name, const std::string& email, const std::string& phone, const std::vector<Purchase>& history);
    void addPurchase(const Purchase& purchase);
    std::vector<Purchase> getHistory() const;
};

#endif
