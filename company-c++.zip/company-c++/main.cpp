#include <iostream>
#include "Customer.h"
#include "Purchase.h"
#include "Employee.h"
#include <fstream>
#include <vector>
std::string getEmployee();
std::string getCustomer();
std::vector<Employee> EMPLOYEE_LIST;
std::vector<Customer> CUSTOMER_LIST;
std::string COMPANY_NAME;
void addCustomerDetails(const Customer& customer);
void addPurchase(int index, const Purchase& purchase);
void displayCustomerNames();
void displayCustomerDetails(int index);
void saveToFile();
void initializeMap();
void displayMainMenu();
void selectOne();
void selectTwo();
void addEmployee(const Employee& employee);
Customer readCustomer();
Employee readEmployee();
Purchase readPurchase();
void displayEmployees();



void readFile();

void initializeMap() {
    readFile();
}

void displayMainMenu() {
    std::cout << "  MAIN MENU \n 1.) Employees \n 2.) Sales \n 3.) Quit" << std::endl;

    std::cout << "\n Choice? ";
    int mainMenuChoice;
    std::cin >> mainMenuChoice;
    //std::cout << mainMenuChoice << std::endl;

    switch (mainMenuChoice) {
        case 1:
            displayEmployees();
            selectOne();
            break;
        case 2:
            selectTwo();
            break;
        case 3:
            saveToFile();
            exit(0);
            break;
        default:
            saveToFile();
            std::cout << "Invalid choice selected!!" << std::endl;
    }
}



void selectTwo() {
    std::cout << "(A)dd Customer, Enter a (S)ale, (V)iew Customer, or (M)ain menu ? ";
    std::string choiceTwoOption;
    std::cin >> choiceTwoOption;

    if (choiceTwoOption == "A") {
        addCustomerDetails(readCustomer());
        selectTwo();
    } else if (choiceTwoOption == "S") {

        if(CUSTOMER_LIST.empty())
        {
            std::cout << "Error: No Customers."<< std::endl;
            goto ltr;
        }
        displayCustomerNames();
        std::cout << "Choice? ";
        int customerIndex;
        std::cin >> customerIndex;
        addPurchase(customerIndex - 1, readPurchase());
        selectTwo();
    } else if (choiceTwoOption == "V") {
        if(CUSTOMER_LIST.empty())
        {
            std::cout << "Error: No Customers."<< std::endl;
            goto ltr;
        }
        displayCustomerNames();
        std::cout << "Choice? ";
        int cIndex;
        std::cin >> cIndex;
        displayCustomerDetails(cIndex - 1);
        selectTwo();
    } else if (choiceTwoOption == "M") {
        displayMainMenu();
    }
    ltr: selectTwo();
}

void displayEmployees() {
    for (const Employee& employee : EMPLOYEE_LIST) {
        employee.display();
    }
}

void selectOne() {
    std::cout << "(A)dd Employee or (M)ain Menu? ";
    std::string choiceOneOption;
    std::cin >> choiceOneOption;

    if (choiceOneOption == "A") {
        addEmployee(readEmployee());
        displayEmployees();
        selectOne();
    } else if (choiceOneOption == "M") {
        displayMainMenu();
    }
}

Employee readEmployee() {
    Employee employee;
    std::string name, email, phone;
    double salary;

    std::cout << "Name: ";
    std::cin.ignore();
    std::getline(std::cin, name);
    employee.setName(name);

    std::cout << "Email: ";
    std::getline(std::cin, email);
    employee.setEmail(email);

    std::cout << "Phone: ";
    std::getline(std::cin, phone);
    employee.setPhone(phone);

    std::cout << "Salary: ";
    std::cin >> salary;
    employee.setSalary(salary);

    return employee;
}

Purchase readPurchase() {
    Purchase purchase;
    std::string item;
    int quantity;
    double cost;

    std::cout << "Item: ";
    std::cin.ignore();
    std::getline(std::cin, item);
    purchase.setItem(item);

    std::cout << "Quantity: ";
    std::cin >> quantity;
    purchase.setQuantity(quantity);

    std::cout << "Cost: ";
    std::cin >> cost;
    purchase.setCost(cost);

    return purchase;
}

void addEmployee(const Employee& employee) {
    EMPLOYEE_LIST.push_back(employee);
}

Customer readCustomer() {
    Customer customer;
    std::string name, email, phone;

    std::cout << "Name: ";
    std::cin.ignore();
    std::getline(std::cin, name);
    customer.setName(name);

    std::cout << "Email: ";
    std::getline(std::cin, email);
    customer.setEmail(email);

    std::cout << "Phone: ";
    std::getline(std::cin, phone);
    customer.setPhone(phone);

    return customer;
}

void addCustomerDetails(const Customer& customer) {
    CUSTOMER_LIST.push_back(customer);
}

void addPurchase(int index, const Purchase& purchase) {
    Customer& customer = CUSTOMER_LIST[index];
    customer.addPurchase(purchase);
}

void displayCustomerNames() {
    int i = 1;
    for (const Customer& customer : CUSTOMER_LIST) {
        std::cout << i << ".) " << customer.getName() << std::endl;
        i++;
    }
}

void displayCustomerDetails(int index) {
    const Customer& customer = CUSTOMER_LIST[index];
    customer.display();
    std::cout << "Order History" << std::endl;
    std::cout << "Item                      Price       Quantity            Total" << std::endl;
    for (const Purchase& purchase : customer.getHistory()) {
        purchase.display();
    }
}

void saveToFile() {
    std::string fileData = "";
    fileData += getEmployee();
    fileData += getCustomer();
    try {
        std::ofstream outFile(COMPANY_NAME + ".dat");
        outFile << fileData;
        outFile.close();
    } catch (std::exception& e) {
        std::cerr << "Failed to write to file: " << e.what() << std::endl;
    }
}

std::string getEmployee() {
    std::string empData = "";
    if (EMPLOYEE_LIST.size() > 0) {
        empData += std::to_string(EMPLOYEE_LIST.size()) + "\n";
        for (const Employee& employee : EMPLOYEE_LIST) {
            empData += employee.getName() + "\n";
            empData += employee.getEmail() + "\n";
            empData += employee.getPhone() + "\n";
            empData += std::to_string(employee.getSalary()) + "\n";
        }
    }
    return empData;
}

std::string getCustomer() {
    std::string customerData = "";
    if (CUSTOMER_LIST.size() > 0) {
        customerData += std::to_string(CUSTOMER_LIST.size()) + "\n";
        for (const Customer& customer : CUSTOMER_LIST) {
            customerData += customer.getName() + "\n";
            customerData += customer.getEmail() + "\n";
            customerData += customer.getPhone() + "\n";
            const std::vector<Purchase>& purchases = customer.getHistory();
            if (purchases.size() > 0) {
                customerData += std::to_string(purchases.size()) + "\n";
                for (const Purchase& purchase : purchases) {
                    customerData += purchase.getItem() + "\n";
                    customerData += std::to_string(purchase.getQuantity()) + "\n";
                    customerData += std::to_string(purchase.getCost()) + "\n";
                }
            }
        }
    }
    return customerData;
}

void readFile() {
    std::ifstream inFile(COMPANY_NAME + ".dat");
    if (!inFile) {

        return;
    }

    int numEmployees = 0;
    std::string line;
    if (std::getline(inFile, line)) {
        try {
            numEmployees = std::stoi(line);
        } catch (std::exception& e) {
            std::cerr << "Error parsing number of employees: " << e.what() << std::endl;
        }
    }

    for (int i = 0; i < numEmployees; i++) {
        std::string name, email, phone, salaryStr;
        double salary;

        if (std::getline(inFile, name) && std::getline(inFile, email) && std::getline(inFile, phone) && std::getline(inFile, salaryStr)) {
            try {
                salary = std::stod(salaryStr);
            } catch (std::exception& e) {
                std::cerr << "Error parsing employee salary: " << e.what() << std::endl;
                continue;
            }

            Employee employee(name, email, phone, salary);
            EMPLOYEE_LIST.push_back(employee);
        } else {
            std::cerr << "Invalid data for employee at line: " << i << std::endl;
        }
    }

    std::string numCustomersStr;
    int numCustomers = 0;
    if (std::getline(inFile, numCustomersStr)) {
        try {
            numCustomers = std::stoi(numCustomersStr);
        } catch (std::exception& e) {
            std::cerr << "Error parsing number of customers: " << e.what() << std::endl;
        }
    }

    for (int i = 0; i < numCustomers; i++) {
        std::string name, email, phone, numPurchasesStr;
        int numPurchases;

        if (std::getline(inFile, name) && std::getline(inFile, email) && std::getline(inFile, phone) && std::getline(inFile, numPurchasesStr)) {
            try {
                numPurchases = std::stoi(numPurchasesStr);
            } catch (std::exception& e) {
                std::cerr << "Error parsing number of purchases for customer: " << e.what() << std::endl;
                continue;
            }

            std::vector<Purchase> purchases;
            for (int j = 0; j < numPurchases; j++) {
                std::string item, quantityStr, costStr;
                int quantity;
                double cost;

                if (std::getline(inFile, item) && std::getline(inFile, quantityStr) && std::getline(inFile, costStr)) {
                    try {
                        quantity = std::stoi(quantityStr);
                        cost = std::stod(costStr);
                    } catch (std::exception& e) {
                        std::cerr << "Error parsing purchase data for customer: " << e.what() << std::endl;
                        continue;
                    }

                    Purchase purchase(item, quantity, cost);
                    purchases.push_back(purchase);
                } else {
                    std::cerr << "Invalid data for purchase at line: " << i << std::endl;
                }
            }

            Customer customer(name, email, phone, purchases);
            CUSTOMER_LIST.push_back(customer);
        } else {
            std::cerr << "Invalid data for customer at line: " << i << std::endl;
        }
    }

    inFile.close();
}


int main() {
    std::cout << "Enter Company Name: ";
    std::getline(std::cin, COMPANY_NAME);
    initializeMap();

    // Company data is initialized

    displayMainMenu();

    return 0;
}
