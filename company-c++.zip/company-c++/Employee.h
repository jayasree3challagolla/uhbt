#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "Person.h"

class Employee : public Person {
private:
    double salary;

public:
    Employee();
    Employee(const std::string& name, const std::string& email, const std::string& phone, double salary);
    double getSalary() const;
    void setSalary(double salary);
    std::string toString() const;
    void display() const;
};

#endif
