#include <iostream>
#include "Employee.h"
#include <sstream>
#include <iomanip>
#include <cmath>


Employee::Employee() {}

Employee::Employee(const std::string& name, const std::string& email, const std::string& phone, double salary)
    : Person(name, email, phone), salary(salary) {}

double Employee::getSalary() const {
    return salary;
}

void Employee::setSalary(double salary) {
    this->salary = salary;
}

std::string Employee::toString() const {
    std::stringstream ss;
    ss << std::fixed << std::setprecision(2) << salary;

    return getName() + " <" + getEmail() + "> Phone: " + getPhone() + " Salary: " + ss.str();
}

void Employee::display() const {
    std::cout << toString() << std::endl;
}






